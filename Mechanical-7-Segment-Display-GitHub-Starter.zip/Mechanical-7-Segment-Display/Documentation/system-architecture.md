# System architecture

## Intended data flow

1. Python logic runs on the NVIDIA Jetson Nano.
2. The Jetson Nano sends a serial command over USB.
3. The Arduino receives and interprets the command.
4. The Arduino communicates with the PCA9685 PWM driver over I2C.
5. The PWM driver sends control signals to the servo motors.
6. The servo-driven segments move to form the requested digit pattern.

## Important distinction
The Jetson Nano is an AI-capable edge-computing platform, but the mechanical display function described here uses it as a Linux/Python host. AI inference is not part of this documented workflow.

## Update this document
Add the actual wiring diagram, board addresses, serial settings, servo channel map, and photographs once verified on the physical prototype.
