# Mechanical 7-Segment Display

A robotics and embedded-systems project exploring a physical, servo-driven seven-segment display.

## Project concept
Individual mechanical segments move to form numerical digits. The intended system architecture uses:
- **Arduino** for low-level control and serial command handling
- **PCA9685 PWM driver** for servo signal generation
- **Servo motors** to move the mechanical segments
- **NVIDIA Jetson Nano** as a Linux-based host for Python-side logic and communication

> **Project status:** This repository is a documentation and starter-code scaffold. Replace assumptions with details from the actual prototype and test all code with the real hardware before use.

## Repository structure
- `Arduino/` — starter Arduino controller
- `Jetson-Nano/` — Python serial communication example
- `Hardware/` — component inventory template
- `Documentation/` — system overview
- `Challenges-and-Solutions/` — engineering challenge log
- `Media/` — add your own prototype photos and demonstration videos

## Getting started
1. Confirm the PCA9685 I2C address and servo channel mapping.
2. Confirm the servo power supply rating and common-ground wiring.
3. Install the Arduino library listed in `Arduino/README.md`.
4. Review and edit the serial settings in both example programs.
5. Test one servo at a time before connecting the complete mechanism.

## Important
The included code is illustrative starter code, not verified original firmware for the user's exact build. Servo angles, channel assignments, pulse limits, I2C addresses, baud rate, and power requirements must be checked against the real hardware.
