# Project media

Add your own original project media here:
- `prototype-overview.jpg` — complete setup
- `mechanism-closeup.jpg` — moving segments and servo linkages
- `electronics.jpg` — Jetson Nano, Arduino, and PWM driver
- `working-demo.mp4` — short video of the display moving

Only use photos and videos of your actual build. Avoid adding stock product images as evidence of components you did not use.
