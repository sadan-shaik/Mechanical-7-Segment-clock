# Arduino controller

Install the **Adafruit PWM Servo Driver Library** using the Arduino IDE Library Manager.

The example sketch assumes:
- PCA9685 address: `0x40`
- Serial baud rate: `115200`
- Servo command format: `S,<channel>,<angle>`
- Example pulse range: 150–375

These are placeholders based on an earlier project configuration. Verify them before connecting the full mechanism. Calibrate each servo carefully and do not force the mechanical segments against their end stops.
