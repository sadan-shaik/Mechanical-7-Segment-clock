#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver(0x40);

const int SERVO_MIN = 150; // Verify for your servos and mechanism
const int SERVO_MAX = 375; // Verify for your servos and mechanism
const int SERVO_COUNT = 16;

void setServoAngle(uint8_t channel, int angle) {
  if (channel >= SERVO_COUNT) return;
  angle = constrain(angle, 0, 180);
  int pulse = map(angle, 0, 180, SERVO_MIN, SERVO_MAX);
  pwm.setPWM(channel, 0, pulse);
}

void setup() {
  Serial.begin(115200); // Must match the Jetson-side setting
  Wire.begin();
  pwm.begin();
  pwm.setPWMFreq(50);
  Serial.println("READY");
}

void loop() {
  if (!Serial.available()) return;

  String command = Serial.readStringUntil('\n');
  command.trim();

  // Expected format: S,<channel>,<angle>
  if (!command.startsWith("S,")) return;

  int firstComma = command.indexOf(',');
  int secondComma = command.indexOf(',', firstComma + 1);
  if (secondComma < 0) return;

  int channel = command.substring(firstComma + 1, secondComma).toInt();
  int angle = command.substring(secondComma + 1).toInt();

  if (channel >= 0 && channel < SERVO_COUNT) {
    setServoAngle((uint8_t)channel, angle);
    Serial.println("OK");
  } else {
    Serial.println("ERR");
  }
}
