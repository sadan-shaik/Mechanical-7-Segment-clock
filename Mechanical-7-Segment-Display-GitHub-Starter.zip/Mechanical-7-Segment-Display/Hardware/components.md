# Hardware inventory

Fill in the exact model, quantity, and specifications from the physical build.

| Component | Purpose | Actual model / quantity |
|---|---|---|
| NVIDIA Jetson Nano | Linux host for Python logic and serial communication | Confirm exact board variant |
| Arduino board | Servo command controller | Confirm exact board |
| PCA9685 PWM driver | Generates servo PWM signals | Confirm board count and I2C address(es) |
| Servo motors | Move mechanical display segments | Confirm model and quantity |
| External servo power supply | Powers servo motors | Confirm voltage/current rating |
| Mechanical frame and segments | Supports the moving display | Add material and dimensions |
| USB cable | Serial connection between host and Arduino | Confirm cable type |

## Wiring notes to verify
- Servo power should come from a suitable external supply, not from the Jetson Nano's GPIO pins.
- Connect the grounds of the controller, PWM driver, and external servo supply as required by the driver design.
- Verify I2C wiring, address jumpers, voltage compatibility, and current capacity against the actual modules.
- Do not assume the example channel mapping matches the prototype.
