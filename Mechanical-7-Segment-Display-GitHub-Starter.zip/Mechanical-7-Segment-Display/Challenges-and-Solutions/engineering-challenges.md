# Engineering challenges and solutions

Use this log to document what was actually encountered and how it was resolved. Do not claim a solution until it has been tested.

| Challenge area | What to document | Evidence to add |
|---|---|---|
| Mechanical alignment | Segment geometry, pivot alignment, clearances | Close-up photos or CAD drawing |
| Servo calibration | Angle limits and repeatable segment positions | Calibration table / video |
| Multi-servo control | Channel mapping and coordinated movement | Wiring photo and test results |
| Power distribution | Supply rating, voltage drop, ground arrangement | Power-supply label and measured values |
| Jetson–Arduino communication | Device name, baud rate, command format, errors | Terminal output |
| System reliability | Repeated switching tests and observed failures | Test log and demo video |

## Add your real results
For each challenge, write:
- **Problem:** What happened?
- **Cause:** What did you identify?
- **Solution:** What change did you make?
- **Verification:** How did you confirm it worked?
