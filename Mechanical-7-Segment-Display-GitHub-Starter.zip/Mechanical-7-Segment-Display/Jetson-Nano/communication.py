"""Illustrative serial command sender for the mechanical display.

Check the actual serial device and baud rate on your Jetson Nano before use.
This example sends one command only; it does not implement a full clock.
"""

import time
import serial

SERIAL_PORT = "/dev/ttyUSB0"  # Verify with: ls /dev/ttyUSB*
BAUD_RATE = 115200             # Must match the Arduino sketch

def main():
    with serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=2) as board:
        time.sleep(2)  # Allow the Arduino to reset after serial connection
        # Example only: move PCA9685 channel 0 to 90 degrees
        board.write(b"S,0,90\n")
        response = board.readline().decode(errors="replace").strip()
        print("Arduino response:", response or "(no response)")

if __name__ == "__main__":
    main()
