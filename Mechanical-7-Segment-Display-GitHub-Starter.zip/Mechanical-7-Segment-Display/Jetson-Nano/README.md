# Jetson Nano host-side communication

This folder contains a small Python example showing how a Linux host can send servo-position commands to the Arduino over USB serial.

The Jetson Nano is used here as a host computer for Python logic and communication. This project does not require AI inference; do not describe it as an AI-powered display unless an actual AI feature is added and tested.
